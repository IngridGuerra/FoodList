//
//  RandomInt.swift
//  Home
//
//  Created by UDLAP20 on 2/18/20.
//  Copyright © 2020 UDLAP20. All rights reserved.
//

import Foundation
// A random generated Int between 0 and lessThan -1
class RandomInt {
    var value: Int
    
    init(lessThan: Int) {
        var randomNumber: UInt32
        randomNumber = arc4random_uniform(UInt32(lessThan))
        value = Int(randomNumber)
        
    }
    
}
