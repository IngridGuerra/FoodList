//
//  TableViewController.swift
//  Home
//
//  Created by UDLAP20 on 2/20/20.
//  Copyright © 2020 UDLAP20. All rights reserved.
//

import Foundation
import UIKit

class TableViewController: UITableViewController {
    
    @IBAction func addNewItem(_ sender: UIBarButtonItem) {
        var newItem: Item
        var indexPath: IndexPath
        
        //Updating the Model
        //Create a new Item and add it
        newItem = Item()
        Model.addItem(newItem)
        
        //Updating the View
        // Figure out where that item is in the array (the path)
        if let index = Model.items.firstIndex(of: newItem) {
            indexPath = IndexPath(row: index, section: 0)
            //Insert this new row into the table view, with animation
            tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        navigationItem.leftBarButtonItem = editButtonItem
    }
    
    private func initializeView(){
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 65
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Model doesn't need to be initialized
        initializeView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        tableView.reloadData()
    }
    
    //The prepare function is called when a segue is about to be performed
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        var detailViewController: DetailViewController
        
        // if the triggered segue is the "showItem" segue
        switch segue.identifier {
        case "showItem"?:
            // Figure out which row was just tapped
            if let row = tableView.indexPathForSelectedRow?.row{
                // Get the item associated with this row and pass it along
                let item = Model.items[row]
                detailViewController = segue.destination as! DetailViewController
                detailViewController.item = item
            }
        default:
            preconditionFailure("Unexpected segue identifier")
        }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        Model.moveItem(fromIndex: sourceIndexPath.row, toIndex: destinationIndexPath.row)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        var item: Item
        var title: String
        var alertController : UIAlertController
        var cancelAction : UIAlertAction
        var deleteAction : UIAlertAction
        
        
        if editingStyle == UITableViewCell.EditingStyle.delete{
            item = Model.items[indexPath.row]
            title = "Erase \(item.name)?"
            
            //Creates a dialog
            alertController = UIAlertController(title: title, message: "Really?", preferredStyle: UIAlertController.Style.alert)
            
            cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
            alertController.addAction(cancelAction)
            
            // FOR REMOVING ITEMS IN STORE
            deleteAction = UIAlertAction(title: "Erase", style: UIAlertAction.Style.destructive, handler: { (action) -> Void in
                Model.removeItem(item)
                // Removes the row from the table view with animation
                self.tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
            })
            
            alertController.addAction(deleteAction)
            present(alertController, animated: true, completion: nil)
        }
    }
    
    //To let know Swift the total number of rows/items in the model
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : ItemCell
        var item : Item
        
        // Constructs an instance of a UITableViewCell with default appearance and CELL ID
        cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) as! ItemCell
        
        // Set text on the cell with the description of the item
        // n = row
        item = Model.items[indexPath.row]
        
        cell.nameLabel.text = item.name
        cell.serialNumberLabel.text = item.serialNumber
        cell.valueLabel.text = "$\(item.value)"
        
        return cell
    }
}
