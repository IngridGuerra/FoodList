//
//  Model.swift
//  Home
//
//  Created by UDLAP20 on 2/18/20.
//  Copyright © 2020 UDLAP20. All rights reserved.
//

import Foundation

class Model{
    static var items: Array<Item> = []
    
    static func addItem(_ item: Item){
        items.append(item)
    }
    
    static func removeItem(_ item: Item){
        if let index = items.firstIndex(of: item){
            items.remove(at: index)
        }
    }
    
    static func moveItem(fromIndex: Int, toIndex: Int){
        var movedItem: Item
        
        if fromIndex != toIndex {
            //Get reference to object being moved so you can reinsert it
            movedItem = items[fromIndex]
            //Remove item from array
            items.remove(at: fromIndex)
            //Insert item in array at new location
            items.insert(movedItem, at: toIndex)
        }
    }
    
    
}
