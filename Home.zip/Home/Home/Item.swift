//
//  Item.swift
//  Home
//
//  Created by UDLAP20 on 2/18/20.
//  Copyright © 2020 UDLAP20. All rights reserved.
//

import Foundation

//NSObject = Next Step Object

class Item: NSObject {
    var name: String
    var value: Int
    var serialNumber: String?
    let dateCreated: Date
    
    static let adjectives = ["Tasty", "Original", "New", "Traditional", "Cold", "Hot", "Cheap", "Delicious"]
    static let nouns = ["Tacos", "Tamales", "Chilaquiles", "Molotes", "Tlacoyos", "Sopes", "Huaraches"]
    
    override init() {
        var random: RandomInt
        var randomSerialNumber: String
        var universalyUniqueID: UUID
        var randomAdjective: String
        var randomNoun: String
        var randomName: String
        
        random = RandomInt(lessThan: Item.adjectives.count)
        randomAdjective = Item.adjectives[random.value]
        random = RandomInt(lessThan: Item.nouns.count)
        randomNoun = Item.nouns[random.value]
        randomName = "\(randomAdjective) \(randomNoun)"
        name = randomName
        
        universalyUniqueID = UUID()
        print(universalyUniqueID.uuidString)
        randomSerialNumber = universalyUniqueID.uuidString.components(separatedBy: "-").first!
        serialNumber = randomSerialNumber
        
        random = RandomInt(lessThan: 40)
        value = random.value
        
        dateCreated = Date()
    }
    
    
}
